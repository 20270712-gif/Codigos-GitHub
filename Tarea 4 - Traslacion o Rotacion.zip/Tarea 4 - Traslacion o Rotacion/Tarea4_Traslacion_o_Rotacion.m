close all
clear
clc
clf

DibujaEjes(3)

[ W, L, H] = LeerDim();
fprintf("[DEBUG] Ancho: %f | Largo: %f | Alto: %f \n", W, L, H);

PointMatrix = GetPointMatrix(L, W, H, 0, 0, 0);
DibujaCaja(PointMatrix, "blue");

fprintf("\n1. Traslacion\n");
fprintf("2. Rotacion\n");
Tipo = input("Elige el tipo de movimiento: ");
if Tipo == 1
    dx = input("Cuanto se mueve en X [m]: ");
    dy = input("Cuanto se mueve en Y [m]: ");
    dz = input("Cuanto se mueve en Z [m]: ");
elseif Tipo == 2
    Theta = input("Indica el angulo de rotacion [rad]: ");
end

for t = 0:0.05:1
    if Tipo == 1
        NewPoints = Traslacion(dx*t, dy*t, dz*t, PointMatrix);
    elseif Tipo == 2
        NewPoints = MoverCaja(Theta*t, PointMatrix);
    end

    clf
    DibujaEjes(3)
    DibujaCaja(NewPoints, "red");
    pause(0.1)
end

%________ TAREA _________ %

%   Parte 1
%   Modificar New Points para que caja 2(rotacion)
%   sea diferente color a caja 1(original) > modificar DibujarCaja()

%   Part 2
%   Agregar espacio para elegir tipo de mov.
%   (traslacion x, y o z, o rotacion en z) y generar animacion